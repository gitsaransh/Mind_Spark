package com.mindspark.puzzlegame;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
